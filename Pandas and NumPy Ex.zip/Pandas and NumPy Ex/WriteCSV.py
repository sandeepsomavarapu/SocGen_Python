import pandas as pd  
# data = {'Name': ['Smith', 'Parker'], 'ID': [101, 102], 'Language': ['Python', 'JavaScript']}  
# info = pd.DataFrame(data)  
# print('DataFrame Values:\n', info)  
# default CSV  csv_data = info.to_csv(sep='|')  
df=pd.read_csv("cities.csv")
print(df.head(2))
print(df.tail(2))
print(df.info())

#print(df.to_string())
# df=pd.read_excel("Day-wise attendance.xlsx")#py -m pip install openpyxl
# print(df)
# df1=pd.read_json("sample4.json")
# print(df1.to_string())
