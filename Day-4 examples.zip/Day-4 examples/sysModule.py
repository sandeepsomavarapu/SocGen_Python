import sys

#print(sys.path)
print(sys.argv)
print(sys.version)