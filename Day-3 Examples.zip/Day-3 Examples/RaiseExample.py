class InvalidAgeException(Exception):
    def __init__(self,msg):
        self.msg=msg
age=int(input("Enter your age : "))
if age<18:
    raise InvalidAgeException("You Are Not Allowed To Vote")
else:
    print("You can caste your vote")
print("Remaining lines code ...")