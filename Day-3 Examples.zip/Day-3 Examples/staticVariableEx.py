class Test:
	x=123#static
	def __init__(self,y):
		self.y=y#instance
		Test.countryName="india" #static
	def m1(self):
		Test.countryCode=91 #static
t1=Test(124)
t2=Test(125)
print('t1:',t1.x,t1.y)
print('t2:',t2.x,t2.y)
Test.x=777#access static
t1.y=666#access instance
print('t1:',t1.x,t1.y)
print('t2:',t2.x,t2.y)