class Employee: #constructor overloading not supported by python
    age=123#Data members and member functions
    def __init__(self):#constructor
        print("am from default constructor :")
    def welcomeMsg(self):#instance method
        print("am from default function")


emp=Employee()#object creation
emp.welcomeMsg()
emp1=Employee()
