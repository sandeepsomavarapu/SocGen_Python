import gc
import time

class Test:
    def __init__(self) :
        print("Object Intializing....")
    def __del__(self) :
        print("just before garbage collection")
test=Test()
test=None
time.sleep(5)
print("End ....")

# print(gc.isenabled())
# gc.disable()
# print(gc.isenabled())


#super()