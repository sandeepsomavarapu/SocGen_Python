class Test:
	a=10  #public 		any where we can access 
	_b=20 #protected	inside the class and its derived/child class
	__c=90#private		only inside the class 
	def m1(self):
		print(Test.a)
		print(Test._b)
		print(Test.__c)

t=Test()
t.m1()
print(Test.a)
print(Test._b)
print(Test.__c)
