import re
data=input("Enter the pattern to check..")
matchobj=re.fullmatch(data,"abcdefg")
print(matchobj)
if(matchobj!=None):
    print("start index",matchobj.start(),"end index",matchobj.end())
else:
    print("no match  for  the complete string")    